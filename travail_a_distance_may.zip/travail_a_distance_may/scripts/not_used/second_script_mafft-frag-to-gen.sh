#!/bin/bash


### SLURM PARAMETERS ###
#SBATCH --cpus-per-task=12
#SBATCH --partition short
#SBATCH --mail-user=ievbalt@gmail.com
#SBATCH --mail-type=ALL


### MODULES ###
module load mafft/7.505


### PATHS ###
path_to_dir="/users/baltusyte";
path_to_tmp="/scratch/baltusyte""$SLURM_JOB_ID"; 
path_to_dest="/users/baltusyte";


### ANALYSIS ###

# Make a temporary dir into the scratch
mkdir $path_to_tmp

# Copy data from home to scratch
scp san:$path_to_dir/2284_strand_reps_procedded_without_170_empty_seq.fasta $path_to_tmp
scp san:$path_to_dir/ABCD_aligned.fasta $path_to_tmp


# Run MAFFT
mafft --thread 12 --inputorder --maxiterate 1000 --localpair --addfragments $path_to_tmp/2284_strand_reps_procedded_without_170_empty_seq.fasta $path_to_tmp/ABCD_aligned.fasta > $path_to_tmp/hpv16_representative_complete_genomes_and_representative_portions_rep_edit_sequences_aligned.fasta


### FINALISE ###

# Transfer data
scp $path_to_tmp/hpv16_representative_complete_genomes_and_representative_portions_rep_edit_sequences_aligned.fasta san:$path_to_dest/;
echo "Data transfer node -> san";

# Remove scratch dir
rm -rf $path_to_tmp;
echo "Data deletion on node";
