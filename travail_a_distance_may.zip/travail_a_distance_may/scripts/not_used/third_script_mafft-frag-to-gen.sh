#!/bin/bash

###### SLURM Configuration###
### SLURM PARAMETERS ###
#SBATCH --cpus-per-task=12
#SBATCH --partition short
#SBATCH --mail-user=ievbalt@gmail.com
#SBATCH --mail-type=ALL
##############################

# creer son repertoire perso
mkdir /scratch/baltusyte-$SLURM_JOB_ID

# recuperer les donnees ( faut changer pour le rep specifique)
scp -pr fragments_to_genomes /scratch/baltusyte-$SLURM_JOB_ID

# charger le logiciel a utiliser
module load mafft/7.505

# lancer l analyse
cd /scratch/baltusyte-$SLURM_JOB_ID/fragments_to_genomes
mafft --thread 12 --inputorder --maxiterate 1000 --localpair --addfragments 2284_strand_reps_procedded_without_170_empty_seq.fasta ABCD_aligned.fasta > hpv16_representative_complete_genomes_and_representative_portions_rep_edit_sequences_aligned.fasta

# recuperer les resultats
scp -pr /scratch/baltusyte-$SLURM_JOB_ID/fragments_to_genomes /users/baltusyte/F2G_FINISHED

# suppression des donnees sur le scratch
cd /scratch
rm -rf baltusyte-$SLURM_JOB_ID
