#!/usr/bin/env python3#!/usr/bin/env python3

def parse_representatives(rep_file):
    representatives = set()
    with open(rep_file, 'r') as file:
        for line in file:
            if line.startswith('>'):
                rep = line.strip()[1:]  # Remove the '>' character
                representatives.add(rep)
    return representatives

def parse_clustr_file(clustr_file, representatives):
    clusters = {}
    current_cluster = None
    add_cluster = False
    cluster_lines = []
    
    with open(clustr_file, 'r') as file:
        for line in file:
            if line.startswith('>Cluster'):
                if add_cluster:
                    clusters[current_cluster] = cluster_lines
                current_cluster = line.strip()
                cluster_lines = [current_cluster]
                add_cluster = False
            else:
                sequence_id = line.strip().split()[2][1:-3]  # Removing '>' and '...'
                cluster_lines.append(line.strip())
                if sequence_id in representatives:
                    add_cluster = True

        if add_cluster:
            clusters[current_cluster] = cluster_lines

    return clusters

def save_filtered_clusters(clusters, output_file):
    with open(output_file, 'w') as file:
        for cluster_id, sequences in clusters.items():
            for line in sequences:
                file.write(f"{line}\n")

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 4:
        print("Usage: python extract_reps.py <rep_file> <clustr_file> <output_file>")
        sys.exit(1)

    rep_file = sys.argv[1]
    clustr_file = sys.argv[2]
    output_file = sys.argv[3]

    representatives = parse_representatives(rep_file)
    clusters = parse_clustr_file(clustr_file, representatives)
    save_filtered_clusters(clusters, output_file)
