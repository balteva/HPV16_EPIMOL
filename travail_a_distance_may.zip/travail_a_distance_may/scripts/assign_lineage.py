#!/usr/bin/env python3


import os, argparse

def parse_clustr_file(clustr_file):
    clusters = {}
    with open(clustr_file, 'r') as file:
        cluster_id = None
        for line in file:
            if line.startswith('>Cluster'):
                cluster_id = line.strip().replace(">","")
                clusters[cluster_id] = {'representative': None, 'sequences': []}
            else:
                parts = line.strip().split()
                sequence_id = parts[2][1:-3]  # Removing '>' at the start and '...' at the end
                if parts[-1] == '*':  # Representative sequence
                    clusters[cluster_id]['representative'] = sequence_id
                    clusters[cluster_id]['sequences'].append(sequence_id) ## added this line to save the ref 
                else: 
                    clusters[cluster_id]['sequences'].append(sequence_id) 
    return clusters

def parse_lineage_file(lineage_file):
    lineage_dict = {}
    with open(lineage_file, 'r') as file:
        for line in file:
            # Split the line by whitespace
            parts = line.strip().split(maxsplit=1)
            if len(parts) == 2:
                accession, lineage = parts
                lineage_dict[accession] = lineage
            else:
                print(f"Skipping malformed line: {line.strip()}")
    return lineage_dict

##potential issue is here according to sarah
def assign_lineage_to_clusters(clusters, lineage_dict):
    for cluster_id, cluster_data in clusters.items():
        representative = cluster_data['representative']
        lineage = lineage_dict.get(representative, 'Unknown')
        cluster_data['lineage'] = lineage
        cluster_data['sequences_with_lineage'] = [(seq, lineage) for seq in cluster_data['sequences']]
    return clusters


def save_clusters_with_lineage(clusters, output_file):
    with open(output_file, 'w') as file:
        for cluster_id, cluster_data in clusters.items():
            for seq, lineage in cluster_data['sequences_with_lineage']:
                file.write(f"{seq}\t{lineage}\t{cluster_id}\n")

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 4:
        print("Usage: python assign_lineage.py <clustr_file> <lineage_file> <output_file>")
        sys.exit(1)

    clustr_file = sys.argv[1]
    lineage_file = sys.argv[2]
    output_file = sys.argv[3]

    clusters = parse_clustr_file(clustr_file)
    lineage_dict = parse_lineage_file(lineage_file)
    clusters_with_lineage = assign_lineage_to_clusters(clusters, lineage_dict)
    save_clusters_with_lineage(clusters_with_lineage, output_file)
