#!/bin/bash

input_file="classed_hpv16_groups17_05.txt"  # Replace with your input file name
output_file="hpv16_nodes.txt"

# Step 1: Extract the lines with annotations
grep -oP '\[&label="\[I\d+\]"\]' "$input_file" > hpv16_annotations.txt

# Step 2: Extract and clean the annotations
sed -e 's/\[&label="\[I\([0-9]\+\)\]"\]/I\1/'hpv16_annotations.txt > cleaned_annotations.txt

# Step 3: Format the output
# Here, we assume there might be multiple lines that need to be processed in the input file
awk 'BEGIN { OFS="\t" } 
     { 
        if ($1 ~ /^[^#;]/) { 
            print $1 
        } else {
            for (i=1; i<=NF; i++) {
                if ($i ~ /^I[0-9]+$/) { 
                    printf("%s\t", $i) 
                } 
            }
            printf("\n")
        } 
     }' cleaned_annotations.txt > "$output_file"

# Clean up intermediate files
rm hpv16_annotations.txt cleaned_annotations.txt
