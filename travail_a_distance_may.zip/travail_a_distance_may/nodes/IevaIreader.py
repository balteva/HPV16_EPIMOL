string = """

paste ur shit here


"""
string2 = ""
temp = ""
checker = False
gcheck = False
for i in string:
    jump = False
    if i == "I":
        checker = True

    if i == "]":
        if checker:
            jump = True
        checker = False

    if checker:
         string2 += i
    if jump:
        string2 += "    "
    if i == "g":
        temp = ''
        gcheck = True

    if i == "\n":
        if gcheck and "group" in temp and not "gin" in temp:
            string2 += ("\n" + temp + "\n")
            temp = ''
        gcheck = False
    if gcheck:
        temp += i
        
print(string2)
