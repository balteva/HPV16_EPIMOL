cdhit/4.8.1 used for clustering 2 outliers, 7748 fragments and 2937 genomes = 10687 total seq. on cluster
clustered at 99.75 similarity to maintain as much lineage placement as possible (fragment genotype)


result is 3721 reps
