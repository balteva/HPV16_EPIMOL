hpv16_rep_complete_genomes_rep_fragments_and_outliers_ali.fasta is the output file of mafft --addfragments:


cmd line:
mafft --thread 12 --inputorder --maxiterate 1000 --localpair --addfragments fragment_reps_of_10687.fasta ABCD_aligned.fasta > hpv16_rep_complete_genomes_rep_fragments_and_outliers_ali.fasta


input file 1 is the alignment of 133reps of ABCD lineages:
/media/philippepaget-bailly/Ieva_B_M1/HPV16_EPIMOL/may28_rerun/processing_results/ABCD/ABCD_aligned.fasta


input file 2 is the clustered fragments and partial genomes, making up a total of 3721 reps:
/media/philippepaget-bailly/Ieva_B_M1/HPV16_EPIMOL/may28_rerun/processing_results/cd_hit_fragments_may28/fragment_reps_of_10687.fasta
