HPV16_partial_genomes_and_one_empty_full_removed_broken_sequence_virotated.fasta  contains 29936 partial genomes and 1 full genome that was not virotated previously, total = 2937 seq.


HVP16_frag_rc_may28.fasta containts 7748 rc fragment sequences.

Both of these files are concatenated into one and grouped as 'partial genomes and fragments' and make up together 7748 + 2938 = 10685 sequences in may28_2937genomes_7748fragments.fasta


Also added the two possible recombinants that are full genomes, both of which been virotated:
>KY549190.1
>OP728372.1 has been trimmed by ~285nt due to beloning to the faulty guerindian genome publication popset
saved in may28_2outliers_2937genomes_7748fragments.fasta
total count 10687seq.

Will run CD-HIT-EST at 99.75.


This file will be now clustered to reduce redundancy and the representatives will be used in a mafft --add fragments alignment to the ABCD tree.
